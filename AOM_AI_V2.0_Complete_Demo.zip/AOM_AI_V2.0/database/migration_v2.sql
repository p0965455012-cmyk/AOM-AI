-- AOM AI V2.0 additive migration for an existing V1.0 PostgreSQL database.
-- Take a backup before applying. SQLAlchemy create_all also creates missing tables on startup.
CREATE TABLE IF NOT EXISTS shift_assignments (
 id SERIAL PRIMARY KEY, organization_id INTEGER NOT NULL REFERENCES organizations(id),
 shift_id INTEGER NOT NULL REFERENCES shifts(id), employee_id INTEGER NOT NULL REFERENCES employees(id),
 status VARCHAR(30) NOT NULL DEFAULT 'assigned', created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT uq_shift_employee UNIQUE(shift_id, employee_id)
);
CREATE INDEX IF NOT EXISTS ix_shift_assignments_org ON shift_assignments(organization_id);
CREATE TABLE IF NOT EXISTS employee_preferences (
 id SERIAL PRIMARY KEY, organization_id INTEGER NOT NULL REFERENCES organizations(id),
 employee_id INTEGER NOT NULL REFERENCES employees(id), preference_date DATE NOT NULL,
 available_from VARCHAR(5) NOT NULL DEFAULT '00:00', available_to VARCHAR(5) NOT NULL DEFAULT '23:59',
 preferred_store_id INTEGER NULL, note VARCHAR(300) NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS ix_employee_preferences_date ON employee_preferences(preference_date);
CREATE TABLE IF NOT EXISTS leave_requests (
 id SERIAL PRIMARY KEY, organization_id INTEGER NOT NULL REFERENCES organizations(id),
 employee_id INTEGER NOT NULL REFERENCES employees(id), leave_date DATE NOT NULL,
 leave_type VARCHAR(40) NOT NULL DEFAULT '事假', reason VARCHAR(500) NOT NULL DEFAULT '',
 status VARCHAR(30) NOT NULL DEFAULT 'pending', created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS shift_swaps (
 id SERIAL PRIMARY KEY, organization_id INTEGER NOT NULL REFERENCES organizations(id),
 from_assignment_id INTEGER NOT NULL REFERENCES shift_assignments(id),
 to_employee_id INTEGER NOT NULL REFERENCES employees(id), reason VARCHAR(400) NOT NULL DEFAULT '',
 status VARCHAR(30) NOT NULL DEFAULT 'pending', created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS sales_metrics (
 id SERIAL PRIMARY KEY, organization_id INTEGER NOT NULL REFERENCES organizations(id),
 store_id INTEGER NOT NULL REFERENCES stores(id), metric_date DATE NOT NULL,
 sales_amount DOUBLE PRECISION NOT NULL DEFAULT 0, customer_count INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS notifications (
 id SERIAL PRIMARY KEY, organization_id INTEGER NOT NULL REFERENCES organizations(id),
 user_id INTEGER NULL, employee_id INTEGER NULL, title VARCHAR(160) NOT NULL,
 message VARCHAR(600) NOT NULL, channel VARCHAR(30) NOT NULL DEFAULT 'in_app',
 status VARCHAR(30) NOT NULL DEFAULT 'queued', created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS reward_ledger (
 id SERIAL PRIMARY KEY, organization_id INTEGER NOT NULL REFERENCES organizations(id),
 employee_id INTEGER NOT NULL REFERENCES employees(id), points INTEGER NOT NULL,
 reason VARCHAR(300) NOT NULL DEFAULT '跨店支援獎勵', created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS wage_settings (
 id SERIAL PRIMARY KEY, organization_id INTEGER NOT NULL UNIQUE REFERENCES organizations(id),
 hourly_cost DOUBLE PRECISION NOT NULL DEFAULT 190
);

# AOM AI V2.0 架構說明

## 架構
- Web/mobile responsive frontend：HTML/CSS/Vanilla JS。
- API：FastAPI + JWT + role checks。
- Database：PostgreSQL；SQLite 僅供本機快速試跑。
- Automation：n8n webhook；真實 LINE 發送需完成憑證與同意管理。
- Cache/queue foundation：Redis service included，現階段 API 尚未把所有背景工作改為佇列。

## 模組
1. Core：organizations、users、stores、employees、shifts、support_requests、audit_logs。
2. Scheduling：shift_assignments、employee_preferences、auto-assign rule engine。
3. Employee services：leave_requests、shift_swaps、notifications。
4. Workforce intelligence：sales_metrics、forecast endpoint、store analytics、cost estimate。
5. Compliance hints：工時上限、班別重疊、休息間隔及請假衝突提示。
6. Rewards：跨店支援核准後發放展示點數。
7. Assistant：規則型營運問答；非生成式 AI。
8. Integrations：LINE、HR、POS、打卡、地圖、SSO/MFA 狀態盤點。

## 核心 API
- `/api/shifts/{id}/auto-assign`：自動補足班表。
- `/api/assignments`：查詢班表指派。
- `/api/preferences`：登記可上班時段。
- `/api/leaves`、`/api/leaves/{id}/decision`：請假申請與審核。
- `/api/swaps`、`/api/swaps/{id}/decision`：換班申請與審核。
- `/api/sales`、`/api/forecast`：營業資料與需求估算。
- `/api/analytics`、`/api/costs`、`/api/settings/wage`：人力分析與成本。
- `/api/labor-check`：法規風險提示。
- `/api/rewards`、`/api/notifications`、`/api/assistant`、`/api/integrations`。

## 重要設計原則
- 自動排班只產生建議/指派，不得取代主管覆核。
- 員工支援須有明確意願、主管核准與通知紀錄。
- 所有資料查詢應限制 organization_id；正式版還要做 DB row-level security 與跨租戶滲透測試。
- 個資最小化、用途限制、保存期限及員工告知/同意必須在正式導入前完成。

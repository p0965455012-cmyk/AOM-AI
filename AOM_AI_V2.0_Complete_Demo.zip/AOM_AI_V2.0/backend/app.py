import os, json
from datetime import datetime, timedelta, date
from typing import Optional
from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from jose import jwt, JWTError
from passlib.context import CryptContext
from pydantic import BaseModel, Field
from sqlalchemy import create_engine, String, Integer, Boolean, ForeignKey, Date, DateTime, Text, Float, select, func
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker, Session

DATABASE_URL=os.getenv("DATABASE_URL","sqlite:///./aom_v1.db")
JWT_SECRET=os.getenv("JWT_SECRET","LOCAL_DEMO_SECRET_CHANGE_ME")
JWT_EXPIRE_MINUTES=int(os.getenv("JWT_EXPIRE_MINUTES","60"))
N8N_WEBHOOK_URL=os.getenv("N8N_WEBHOOK_URL","")
pwd=CryptContext(schemes=["bcrypt"],deprecated="auto")
oauth=OAuth2PasswordBearer(tokenUrl="/api/auth/token")
engine=create_engine(DATABASE_URL, connect_args={"check_same_thread":False} if DATABASE_URL.startswith("sqlite") else {})
SessionLocal=sessionmaker(bind=engine,autoflush=False,autocommit=False)

class Base(DeclarativeBase): pass
class Organization(Base):
    __tablename__="organizations"
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    name:Mapped[str]=mapped_column(String(200))
    active:Mapped[bool]=mapped_column(Boolean,default=True)
class User(Base):
    __tablename__="users"
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    organization_id:Mapped[int]=mapped_column(ForeignKey("organizations.id"),index=True)
    email:Mapped[str]=mapped_column(String(255),unique=True,index=True)
    full_name:Mapped[str]=mapped_column(String(120))
    password_hash:Mapped[str]=mapped_column(String(255))
    role:Mapped[str]=mapped_column(String(30),default="store_manager")
    active:Mapped[bool]=mapped_column(Boolean,default=True)
class Store(Base):
    __tablename__="stores"
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    organization_id:Mapped[int]=mapped_column(ForeignKey("organizations.id"),index=True)
    code:Mapped[str]=mapped_column(String(50))
    name:Mapped[str]=mapped_column(String(200))
    region:Mapped[str]=mapped_column(String(100),default="")
    address:Mapped[str]=mapped_column(String(300),default="")
    active:Mapped[bool]=mapped_column(Boolean,default=True)
class Employee(Base):
    __tablename__="employees"
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    organization_id:Mapped[int]=mapped_column(ForeignKey("organizations.id"),index=True)
    employee_no:Mapped[str]=mapped_column(String(50))
    name:Mapped[str]=mapped_column(String(100))
    home_store_id:Mapped[int]=mapped_column(ForeignKey("stores.id"))
    skills:Mapped[str]=mapped_column(Text,default="[]")
    support_opt_in:Mapped[bool]=mapped_column(Boolean,default=False)
    available:Mapped[bool]=mapped_column(Boolean,default=True)
    weekly_hours:Mapped[float]=mapped_column(Float,default=0)
    max_weekly_hours:Mapped[float]=mapped_column(Float,default=40)
class Shift(Base):
    __tablename__="shifts"
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    organization_id:Mapped[int]=mapped_column(ForeignKey("organizations.id"),index=True)
    store_id:Mapped[int]=mapped_column(ForeignKey("stores.id"))
    shift_date:Mapped[date]=mapped_column(Date)
    shift_name:Mapped[str]=mapped_column(String(60))
    start_time:Mapped[str]=mapped_column(String(5),default="")
    end_time:Mapped[str]=mapped_column(String(5),default="")
    required_count:Mapped[int]=mapped_column(Integer)
    assigned_count:Mapped[int]=mapped_column(Integer,default=0)
    status:Mapped[str]=mapped_column(String(30),default="open")
class SupportRequest(Base):
    __tablename__="support_requests"
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    organization_id:Mapped[int]=mapped_column(ForeignKey("organizations.id"),index=True)
    shift_id:Mapped[int]=mapped_column(ForeignKey("shifts.id"))
    employee_id:Mapped[int]=mapped_column(ForeignKey("employees.id"))
    status:Mapped[str]=mapped_column(String(30),default="invited")
    score:Mapped[float]=mapped_column(Float,default=0)
    response_at:Mapped[Optional[datetime]]=mapped_column(DateTime,nullable=True)
    decided_by:Mapped[str]=mapped_column(String(120),default="")
class AuditLog(Base):
    __tablename__="audit_logs"
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    organization_id:Mapped[int]=mapped_column(ForeignKey("organizations.id"),index=True)
    actor:Mapped[str]=mapped_column(String(255))
    action:Mapped[str]=mapped_column(String(100))
    entity_type:Mapped[str]=mapped_column(String(100))
    entity_id:Mapped[Optional[int]]=mapped_column(Integer,nullable=True)
    detail:Mapped[str]=mapped_column(Text,default="")
    created_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)

def db():
    s=SessionLocal()
    try: yield s
    finally: s.close()

def seed():
    Base.metadata.create_all(engine)
    s=SessionLocal()
    try:
        if s.scalar(select(func.count(User.id)))==0:
            org=Organization(name="AOM AI 示範企業")
            s.add(org); s.flush()
            u=User(organization_id=org.id,email="admin@demo.aom",full_name="AOM 系統管理員",
                   password_hash=pwd.hash("ChangeMe-Immediately-2026!"),role="super_admin")
            s.add(u)
            stores=[Store(organization_id=org.id,code=f"S{i:03}",name=n,region=r,address=a)
                    for i,(n,r,a) in enumerate([
                    ("台北一店","台北區","台北市"),
                    ("新北二店","新北區","新北市"),
                    ("板橋三店","新北區","新北市")],1)]
            s.add_all(stores); s.flush()
            emps=[
              ("E001","王小明",stores[0].id,["收銀","補貨"],True,True,18),
              ("E002","陳小華",stores[1].id,["收銀","食品作業"],True,True,20),
              ("E003","林小美",stores[2].id,["補貨","清潔"],True,True,16),
              ("E004","張先生",stores[0].id,["收銀","食品作業","補貨"],False,True,24),
              ("E005","李小姐",stores[1].id,["清潔","補貨"],True,False,30)]
            for no,n,st,sk,opt,av,hrs in emps:
                s.add(Employee(organization_id=org.id,employee_no=no,name=n,home_store_id=st,
                    skills=json.dumps(sk,ensure_ascii=False),support_opt_in=opt,available=av,weekly_hours=hrs))
            s.flush()
            s.add_all([
              Shift(organization_id=org.id,store_id=stores[0].id,shift_date=date.today(),
                    shift_name="晚班",start_time="16:00",end_time="00:00",required_count=4,assigned_count=2),
              Shift(organization_id=org.id,store_id=stores[1].id,shift_date=date.today(),
                    shift_name="早班",start_time="07:00",end_time="15:00",required_count=3,assigned_count=3),
              Shift(organization_id=org.id,store_id=stores[2].id,shift_date=date.today(),
                    shift_name="晚班",start_time="15:00",end_time="23:00",required_count=3,assigned_count=2)
            ])
            s.commit()
    finally:s.close()

app=FastAPI(title="AOM AI Enterprise Demo API",version="2.0.0-demo")
@app.on_event("startup")
def startup(): seed()

def current_user(token:str=Depends(oauth),s:Session=Depends(db)):
    try:
        p=jwt.decode(token,JWT_SECRET,algorithms=["HS256"])
        uid=int(p["sub"])
    except (JWTError,KeyError,ValueError):
        raise HTTPException(status_code=401,detail="登入已失效")
    u=s.get(User,uid)
    if not u or not u.active: raise HTTPException(status_code=401,detail="帳號無效")
    return u

def roles(*allowed):
    def check(u:User=Depends(current_user)):
        if u.role not in allowed: raise HTTPException(status_code=403,detail="權限不足")
        return u
    return check

def audit(s,u,action,typ,eid,detail=""):
    s.add(AuditLog(organization_id=u.organization_id,actor=u.email,action=action,entity_type=typ,entity_id=eid,detail=detail))
    s.commit()

class StoreIn(BaseModel):
    code:str; name:str; region:str=""; address:str=""
class EmployeeIn(BaseModel):
    employee_no:str; name:str; home_store_id:int; skills:list[str]=[]
    support_opt_in:bool=False; available:bool=True; weekly_hours:float=0; max_weekly_hours:float=40
class ShiftIn(BaseModel):
    store_id:int; shift_date:date; shift_name:str; required_count:int=Field(ge=1)
    assigned_count:int=Field(default=0,ge=0); start_time:str=""; end_time:str=""
class ReplyIn(BaseModel): willing:bool
class DecisionIn(BaseModel): approved:bool

@app.post("/api/auth/token")
def login(form:OAuth2PasswordRequestForm=Depends(),s:Session=Depends(db)):
    u=s.scalar(select(User).where(User.email==form.username))
    if not u or not pwd.verify(form.password,u.password_hash):
        raise HTTPException(status_code=401,detail="帳號或密碼錯誤")
    token=jwt.encode({"sub":str(u.id),"exp":datetime.utcnow()+timedelta(minutes=JWT_EXPIRE_MINUTES)},JWT_SECRET,algorithm="HS256")
    return {"access_token":token,"token_type":"bearer","name":u.full_name,"role":u.role}

@app.get("/api/me")
def me(u:User=Depends(current_user)):
    return {"id":u.id,"email":u.email,"name":u.full_name,"role":u.role,"organization_id":u.organization_id}

@app.get("/",response_class=HTMLResponse)
def home(): return open("frontend/index.html",encoding="utf-8").read()
app.mount("/static",StaticFiles(directory="frontend"),name="static")

@app.get("/api/dashboard")
def dashboard(s:Session=Depends(db),u:User=Depends(current_user)):
    org=u.organization_id
    return {"stores":s.scalar(select(func.count(Store.id)).where(Store.organization_id==org,Store.active==True)),
      "employees":s.scalar(select(func.count(Employee.id)).where(Employee.organization_id==org)),
      "shifts":s.scalar(select(func.count(Shift.id)).where(Shift.organization_id==org)),
      "shortage_shifts":s.scalar(select(func.count(Shift.id)).where(Shift.organization_id==org,Shift.required_count>Shift.assigned_count))}

@app.get("/api/stores")
def stores(s:Session=Depends(db),u:User=Depends(current_user)):
    return [dict(id=x.id,code=x.code,name=x.name,region=x.region,address=x.address,active=x.active)
      for x in s.scalars(select(Store).where(Store.organization_id==u.organization_id)).all()]

@app.post("/api/stores")
def add_store(x:StoreIn,s:Session=Depends(db),u:User=Depends(roles("super_admin","hq_admin","regional_manager"))):
    if s.scalar(select(Store).where(Store.organization_id==u.organization_id,Store.code==x.code)):
        raise HTTPException(409,"門市代碼已存在")
    o=Store(organization_id=u.organization_id,**x.model_dump());s.add(o);s.commit()
    audit(s,u,"create","store",o.id,o.name);return {"id":o.id,"ok":True}

@app.get("/api/employees")
def employees(s:Session=Depends(db),u:User=Depends(current_user)):
    out=[]
    for e in s.scalars(select(Employee).where(Employee.organization_id==u.organization_id)).all():
        st=s.get(Store,e.home_store_id)
        out.append(dict(id=e.id,employee_no=e.employee_no,name=e.name,home_store_id=e.home_store_id,
          store_name=st.name if st else "",skills=json.loads(e.skills),support_opt_in=e.support_opt_in,
          available=e.available,weekly_hours=e.weekly_hours,max_weekly_hours=e.max_weekly_hours))
    return out

@app.post("/api/employees")
def add_employee(x:EmployeeIn,s:Session=Depends(db),u:User=Depends(roles("super_admin","hq_admin","regional_manager","store_manager"))):
    st=s.get(Store,x.home_store_id)
    if not st or st.organization_id!=u.organization_id: raise HTTPException(404,"門市不存在")
    e=Employee(organization_id=u.organization_id,**{**x.model_dump(),"skills":json.dumps(x.skills,ensure_ascii=False)})
    s.add(e);s.commit();audit(s,u,"create","employee",e.id,e.name);return {"id":e.id,"ok":True}

@app.get("/api/shifts")
def shifts(s:Session=Depends(db),u:User=Depends(current_user)):
    out=[]
    for sh in s.scalars(select(Shift).where(Shift.organization_id==u.organization_id).order_by(Shift.shift_date.desc())).all():
        st=s.get(Store,sh.store_id)
        out.append(dict(id=sh.id,store_id=sh.store_id,store_name=st.name,shift_date=str(sh.shift_date),
          shift_name=sh.shift_name,start_time=sh.start_time,end_time=sh.end_time,required_count=sh.required_count,
          assigned_count=sh.assigned_count,shortage=max(0,sh.required_count-sh.assigned_count)))
    return out

@app.post("/api/shifts")
def add_shift(x:ShiftIn,s:Session=Depends(db),u:User=Depends(roles("super_admin","hq_admin","regional_manager","store_manager"))):
    st=s.get(Store,x.store_id)
    if not st or st.organization_id!=u.organization_id: raise HTTPException(404,"門市不存在")
    sh=Shift(organization_id=u.organization_id,**x.model_dump());s.add(sh);s.commit()
    audit(s,u,"create","shift",sh.id,sh.shift_name);return {"id":sh.id,"ok":True}

@app.post("/api/shifts/{sid}/match")
def match(sid:int,s:Session=Depends(db),u:User=Depends(roles("super_admin","hq_admin","regional_manager","store_manager"))):
    sh=s.scalar(select(Shift).where(Shift.id==sid,Shift.organization_id==u.organization_id))
    if not sh: raise HTTPException(404,"班別不存在")
    gap=max(0,sh.required_count-sh.assigned_count)
    if not gap:return {"shortage":0,"candidates":[]}
    candidates=s.scalars(select(Employee).where(Employee.organization_id==u.organization_id,
       Employee.available==True,Employee.support_opt_in==True,Employee.home_store_id!=sh.store_id)).all()
    ranked=[]
    for e in candidates:
        sk=json.loads(e.skills or "[]")
        if e.weekly_hours>=e.max_weekly_hours: continue
        if _compliance_for_employee(s,u.organization_id,e,sh): continue
        home=s.get(Store,e.home_store_id);target=s.get(Store,sh.store_id)
        same_region=bool(home and target and home.region and home.region==target.region)
        score=60+min(len(sk)*5,20)-max(0,e.weekly_hours/e.max_weekly_hours*20)+(10 if same_region else 0)
        ranked.append({"id":e.id,"name":e.name,"employee_no":e.employee_no,"skills":sk,"same_region":same_region,"score":round(score,1)})
    ranked.sort(key=lambda z:-z["score"])
    for e in ranked[:10]:
        exists=s.scalar(select(SupportRequest).where(SupportRequest.shift_id==sid,SupportRequest.employee_id==e["id"]))
        if not exists:s.add(SupportRequest(organization_id=u.organization_id,shift_id=sid,employee_id=e["id"],score=e["score"]))
    s.commit();audit(s,u,"recommend","shift",sid,f"shortage={gap}; candidates={len(ranked)}")
    return {"shortage":gap,"candidates":ranked[:10],"notice":"展示推薦；正式派班仍須員工同意、法規檢核及主管核准"}

@app.get("/api/support-requests")
def support_requests(s:Session=Depends(db),u:User=Depends(current_user)):
    out=[]
    for r in s.scalars(select(SupportRequest).where(SupportRequest.organization_id==u.organization_id).order_by(SupportRequest.id.desc())).all():
        e=s.get(Employee,r.employee_id);sh=s.get(Shift,r.shift_id);target=s.get(Store,sh.store_id);home=s.get(Store,e.home_store_id)
        out.append(dict(id=r.id,status=r.status,score=r.score,employee_name=e.name,employee_no=e.employee_no,
          home_store=home.name,target_store=target.name,shift_date=str(sh.shift_date),shift_name=sh.shift_name))
    return out

@app.post("/api/support-requests/{rid}/response")
def response(rid:int,x:ReplyIn,s:Session=Depends(db),u:User=Depends(current_user)):
    r=s.scalar(select(SupportRequest).where(SupportRequest.id==rid,SupportRequest.organization_id==u.organization_id))
    if not r or r.status!="invited":raise HTTPException(404,"找不到待回覆邀請")
    r.status="willing" if x.willing else "declined";r.response_at=datetime.utcnow();s.commit()
    audit(s,u,"respond","support_request",rid,r.status);return {"ok":True,"status":r.status}

@app.post("/api/support-requests/{rid}/decision")
def decision(rid:int,x:DecisionIn,s:Session=Depends(db),u:User=Depends(roles("super_admin","hq_admin","regional_manager","store_manager"))):
    r=s.scalar(select(SupportRequest).where(SupportRequest.id==rid,SupportRequest.organization_id==u.organization_id))
    if not r or r.status!="willing":raise HTTPException(409,"只有已表示願意的邀請可審核")
    r.status="approved" if x.approved else "rejected";r.decided_by=u.email
    if x.approved:
        s.add(RewardLedger(organization_id=u.organization_id,employee_id=r.employee_id,points=10,reason="跨店支援核准獎勵"))
        _notify(s,u.organization_id,"跨店支援已核准",f"您的跨店支援申請已核准，獲得 10 點獎勵",employee_id=r.employee_id)
    s.commit()
    audit(s,u,r.status,"support_request",rid,"主管人工審核");return {"ok":True,"status":r.status}

@app.get("/api/audit")
def audit_list(s:Session=Depends(db),u:User=Depends(roles("super_admin","hq_admin","regional_manager"))):
    return [dict(id=x.id,created_at=x.created_at.isoformat(),actor=x.actor,action=x.action,
      entity_type=x.entity_type,entity_id=x.entity_id,detail=x.detail)
      for x in s.scalars(select(AuditLog).where(AuditLog.organization_id==u.organization_id).order_by(AuditLog.id.desc()).limit(200)).all()]

@app.get("/api/health")
def health(): return {"ok":True,"version":"2.0.0-demo"}

# ---------------- AOM AI V2.0 modules ----------------
from sqlalchemy import UniqueConstraint

class ShiftAssignment(Base):
    __tablename__="shift_assignments"
    __table_args__=(UniqueConstraint("shift_id","employee_id",name="uq_shift_employee"),)
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    organization_id:Mapped[int]=mapped_column(ForeignKey("organizations.id"),index=True)
    shift_id:Mapped[int]=mapped_column(ForeignKey("shifts.id"),index=True)
    employee_id:Mapped[int]=mapped_column(ForeignKey("employees.id"),index=True)
    status:Mapped[str]=mapped_column(String(30),default="assigned")
    created_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)

class EmployeePreference(Base):
    __tablename__="employee_preferences"
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    organization_id:Mapped[int]=mapped_column(ForeignKey("organizations.id"),index=True)
    employee_id:Mapped[int]=mapped_column(ForeignKey("employees.id"),index=True)
    preference_date:Mapped[date]=mapped_column(Date,index=True)
    available_from:Mapped[str]=mapped_column(String(5),default="00:00")
    available_to:Mapped[str]=mapped_column(String(5),default="23:59")
    preferred_store_id:Mapped[Optional[int]]=mapped_column(Integer,nullable=True)
    note:Mapped[str]=mapped_column(String(300),default="")

class LeaveRequest(Base):
    __tablename__="leave_requests"
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    organization_id:Mapped[int]=mapped_column(ForeignKey("organizations.id"),index=True)
    employee_id:Mapped[int]=mapped_column(ForeignKey("employees.id"),index=True)
    leave_date:Mapped[date]=mapped_column(Date,index=True)
    leave_type:Mapped[str]=mapped_column(String(40),default="事假")
    reason:Mapped[str]=mapped_column(String(500),default="")
    status:Mapped[str]=mapped_column(String(30),default="pending")
    created_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)

class ShiftSwap(Base):
    __tablename__="shift_swaps"
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    organization_id:Mapped[int]=mapped_column(ForeignKey("organizations.id"),index=True)
    from_assignment_id:Mapped[int]=mapped_column(ForeignKey("shift_assignments.id"))
    to_employee_id:Mapped[int]=mapped_column(ForeignKey("employees.id"))
    reason:Mapped[str]=mapped_column(String(400),default="")
    status:Mapped[str]=mapped_column(String(30),default="pending")
    created_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)

class SalesMetric(Base):
    __tablename__="sales_metrics"
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    organization_id:Mapped[int]=mapped_column(ForeignKey("organizations.id"),index=True)
    store_id:Mapped[int]=mapped_column(ForeignKey("stores.id"),index=True)
    metric_date:Mapped[date]=mapped_column(Date,index=True)
    sales_amount:Mapped[float]=mapped_column(Float,default=0)
    customer_count:Mapped[int]=mapped_column(Integer,default=0)

class InAppNotification(Base):
    __tablename__="notifications"
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    organization_id:Mapped[int]=mapped_column(ForeignKey("organizations.id"),index=True)
    user_id:Mapped[Optional[int]]=mapped_column(Integer,nullable=True,index=True)
    employee_id:Mapped[Optional[int]]=mapped_column(Integer,nullable=True,index=True)
    title:Mapped[str]=mapped_column(String(160))
    message:Mapped[str]=mapped_column(String(600))
    channel:Mapped[str]=mapped_column(String(30),default="in_app")
    status:Mapped[str]=mapped_column(String(30),default="queued")
    created_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)

class RewardLedger(Base):
    __tablename__="reward_ledger"
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    organization_id:Mapped[int]=mapped_column(ForeignKey("organizations.id"),index=True)
    employee_id:Mapped[int]=mapped_column(ForeignKey("employees.id"),index=True)
    points:Mapped[int]=mapped_column(Integer)
    reason:Mapped[str]=mapped_column(String(300),default="跨店支援獎勵")
    created_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)

class WageSetting(Base):
    __tablename__="wage_settings"
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    organization_id:Mapped[int]=mapped_column(ForeignKey("organizations.id"),unique=True,index=True)
    hourly_cost:Mapped[float]=mapped_column(Float,default=190)

class EmployeeInV2(BaseModel):
    employee_id:int
    preference_date:date
    available_from:str="00:00"
    available_to:str="23:59"
    preferred_store_id:Optional[int]=None
    note:str=""
class LeaveIn(BaseModel):
    employee_id:int; leave_date:date; leave_type:str="事假"; reason:str=""
class LeaveDecision(BaseModel): approved:bool
class SwapIn(BaseModel):
    assignment_id:int; to_employee_id:int; reason:str=""
class SwapDecision(BaseModel): approved:bool
class SalesIn(BaseModel):
    store_id:int; metric_date:date; sales_amount:float=Field(ge=0); customer_count:int=Field(ge=0)
class AssistantIn(BaseModel): question:str=Field(min_length=2,max_length=500)
class WageIn(BaseModel): hourly_cost:float=Field(gt=0,le=10000)


def _duration(start,end):
    try:
        a=datetime.strptime(start,"%H:%M");b=datetime.strptime(end,"%H:%M")
        mins=(b-a).total_seconds()/60
        return (mins if mins>0 else mins+1440)/60
    except Exception:return 8.0

def _shift_dt(sh):
    try:
        start=datetime.combine(sh.shift_date,datetime.strptime(sh.start_time or "09:00","%H:%M").time())
        end=datetime.combine(sh.shift_date,datetime.strptime(sh.end_time or "17:00","%H:%M").time())
        if end<=start:end+=timedelta(days=1)
        return start,end
    except Exception:
        start=datetime.combine(sh.shift_date,datetime.min.time())+timedelta(hours=9)
        return start,start+timedelta(hours=8)

def _notify(s,org,title,message,employee_id=None,user_id=None,channel="in_app"):
    s.add(InAppNotification(organization_id=org,user_id=user_id,employee_id=employee_id,title=title,message=message,channel=channel,status="queued"))

def _compliance_for_employee(s,org,emp,sh):
    warnings=[]; start,end=_shift_dt(sh); hours=(end-start).total_seconds()/3600
    if emp.weekly_hours+hours>emp.max_weekly_hours:
        warnings.append(f"預估週工時 {emp.weekly_hours+hours:.1f} 小時，超過個人設定上限 {emp.max_weekly_hours:.1f} 小時")
    existing=s.scalars(select(ShiftAssignment).where(ShiftAssignment.organization_id==org,ShiftAssignment.employee_id==emp.id,ShiftAssignment.status=="assigned")).all()
    for a in existing:
        other=s.get(Shift,a.shift_id)
        if not other or other.id==sh.id:continue
        os_,oe=_shift_dt(other)
        if start<oe and end>os_:warnings.append(f"與既有班別 #{other.id} 時間重疊")
        rest=(start-oe).total_seconds()/3600 if start>=oe else (os_-end).total_seconds()/3600 if end<=os_ else -1
        if 0<=rest<11:warnings.append(f"與既有班別 #{other.id} 間隔僅 {rest:.1f} 小時，低於系統示範休息警示值 11 小時")
    leave=s.scalar(select(LeaveRequest).where(LeaveRequest.organization_id==org,LeaveRequest.employee_id==emp.id,LeaveRequest.leave_date==sh.shift_date,LeaveRequest.status.in_(["pending","approved"])))
    if leave:warnings.append("該員工當日有請假申請或已核准假單")
    pref=s.scalar(select(EmployeePreference).where(EmployeePreference.organization_id==org,EmployeePreference.employee_id==emp.id,EmployeePreference.preference_date==sh.shift_date))
    if pref and (sh.start_time<pref.available_from or sh.end_time>pref.available_to):warnings.append("班別超出員工登記可上班時段")
    return warnings

@app.get("/api/assignments")
def assignments(s:Session=Depends(db),u:User=Depends(current_user)):
    out=[]
    rows=s.scalars(select(ShiftAssignment).where(ShiftAssignment.organization_id==u.organization_id).order_by(ShiftAssignment.id.desc())).all()
    for a in rows:
        e=s.get(Employee,a.employee_id);sh=s.get(Shift,a.shift_id);st=s.get(Store,sh.store_id) if sh else None
        if e and sh:out.append({"id":a.id,"shift_id":sh.id,"employee_id":e.id,"employee_name":e.name,"store":st.name if st else "","date":str(sh.shift_date),"shift_name":sh.shift_name,"status":a.status})
    return out

@app.post("/api/shifts/{sid}/auto-assign")
def auto_assign(sid:int,s:Session=Depends(db),u:User=Depends(roles("super_admin","hq_admin","regional_manager","store_manager"))):
    sh=s.scalar(select(Shift).where(Shift.id==sid,Shift.organization_id==u.organization_id))
    if not sh:raise HTTPException(404,"班別不存在")
    assignment_count=s.scalar(select(func.count(ShiftAssignment.id)).where(ShiftAssignment.shift_id==sid,ShiftAssignment.status=="assigned")) or 0
    # V1.0 shifts may already contain a manually-entered assigned_count without assignment rows.
    assigned=max(sh.assigned_count,assignment_count)
    gap=max(0,sh.required_count-assigned); candidates=[]
    emps=s.scalars(select(Employee).where(Employee.organization_id==u.organization_id,Employee.available==True)).all()
    for e in emps:
        if s.scalar(select(ShiftAssignment.id).where(ShiftAssignment.shift_id==sid,ShiftAssignment.employee_id==e.id)):continue
        warnings=_compliance_for_employee(s,u.organization_id,e,sh)
        if warnings:continue
        score=100-(e.weekly_hours/max(e.max_weekly_hours,1))*35+(10 if e.home_store_id==sh.store_id else 0)
        candidates.append((score,e))
    candidates.sort(key=lambda z:z[0],reverse=True); added=[]
    for score,e in candidates[:gap]:
        s.add(ShiftAssignment(organization_id=u.organization_id,shift_id=sid,employee_id=e.id));added.append(e.name)
        e.weekly_hours+=_duration(sh.start_time,sh.end_time)
        _notify(s,u.organization_id,"新班表指派",f"您已被安排 {sh.shift_date} {sh.shift_name}，請登入系統確認",employee_id=e.id)
    s.flush();sh.assigned_count=assigned+len(added);sh.status="filled" if sh.assigned_count>=sh.required_count else "open";s.commit()
    audit(s,u,"auto_assign","shift",sid,"assigned="+",".join(added))
    return {"shift_id":sid,"assigned":added,"remaining_shortage":max(0,sh.required_count-sh.assigned_count),"notice":"依示範規則排序；正式排班前仍須人資確認工時、休息及適用法規"}

@app.post("/api/preferences")
def save_preference(x:EmployeeInV2,s:Session=Depends(db),u:User=Depends(current_user)):
    e=s.scalar(select(Employee).where(Employee.id==x.employee_id,Employee.organization_id==u.organization_id))
    if not e:raise HTTPException(404,"員工不存在")
    p=s.scalar(select(EmployeePreference).where(EmployeePreference.organization_id==u.organization_id,EmployeePreference.employee_id==e.id,EmployeePreference.preference_date==x.preference_date))
    if not p:p=EmployeePreference(organization_id=u.organization_id,employee_id=e.id,preference_date=x.preference_date);s.add(p)
    for k,v in x.model_dump(exclude={"employee_id","preference_date"}).items():setattr(p,k,v)
    s.commit();audit(s,u,"save_preference","employee",e.id,str(x.preference_date));return {"ok":True}

@app.post("/api/leaves")
def create_leave(x:LeaveIn,s:Session=Depends(db),u:User=Depends(current_user)):
    e=s.scalar(select(Employee).where(Employee.id==x.employee_id,Employee.organization_id==u.organization_id))
    if not e:raise HTTPException(404,"員工不存在")
    r=LeaveRequest(organization_id=u.organization_id,**x.model_dump());s.add(r);s.flush()
    _notify(s,u.organization_id,"收到請假申請",f"{e.name} 申請 {x.leave_date} {x.leave_type}")
    s.commit();audit(s,u,"create","leave_request",r.id,e.name);return {"id":r.id,"status":r.status}

@app.get("/api/leaves")
def list_leaves(s:Session=Depends(db),u:User=Depends(current_user)):
    out=[]
    for r in s.scalars(select(LeaveRequest).where(LeaveRequest.organization_id==u.organization_id).order_by(LeaveRequest.id.desc())).all():
        e=s.get(Employee,r.employee_id);out.append({"id":r.id,"employee":e.name if e else "","employee_id":r.employee_id,"date":str(r.leave_date),"type":r.leave_type,"reason":r.reason,"status":r.status})
    return out

@app.post("/api/leaves/{rid}/decision")
def decide_leave(rid:int,x:LeaveDecision,s:Session=Depends(db),u:User=Depends(roles("super_admin","hq_admin","regional_manager","store_manager"))):
    r=s.scalar(select(LeaveRequest).where(LeaveRequest.id==rid,LeaveRequest.organization_id==u.organization_id))
    if not r or r.status!="pending":raise HTTPException(404,"找不到待審核假單")
    r.status="approved" if x.approved else "rejected";s.commit();audit(s,u,r.status,"leave_request",rid,"主管審核");return {"status":r.status}

@app.post("/api/swaps")
def create_swap(x:SwapIn,s:Session=Depends(db),u:User=Depends(current_user)):
    a=s.scalar(select(ShiftAssignment).where(ShiftAssignment.id==x.assignment_id,ShiftAssignment.organization_id==u.organization_id,ShiftAssignment.status=="assigned"))
    e=s.scalar(select(Employee).where(Employee.id==x.to_employee_id,Employee.organization_id==u.organization_id,Employee.available==True))
    if not a or not e:raise HTTPException(404,"班表或替班員工不存在")
    sh=s.get(Shift,a.shift_id);warnings=_compliance_for_employee(s,u.organization_id,e,sh)
    if warnings:raise HTTPException(409,"替班檢核未通過："+"；".join(warnings))
    r=ShiftSwap(organization_id=u.organization_id,from_assignment_id=a.id,to_employee_id=e.id,reason=x.reason);s.add(r);s.commit();audit(s,u,"create","shift_swap",r.id,"待主管審核");return {"id":r.id,"status":r.status}

@app.get("/api/swaps")
def list_swaps(s:Session=Depends(db),u:User=Depends(current_user)):
    out=[]
    for r in s.scalars(select(ShiftSwap).where(ShiftSwap.organization_id==u.organization_id).order_by(ShiftSwap.id.desc())).all():
        a=s.get(ShiftAssignment,r.from_assignment_id);old=s.get(Employee,a.employee_id) if a else None;new=s.get(Employee,r.to_employee_id);sh=s.get(Shift,a.shift_id) if a else None
        out.append({"id":r.id,"from":old.name if old else "","to":new.name if new else "","date":str(sh.shift_date) if sh else "","shift":sh.shift_name if sh else "","reason":r.reason,"status":r.status})
    return out

@app.post("/api/swaps/{rid}/decision")
def decide_swap(rid:int,x:SwapDecision,s:Session=Depends(db),u:User=Depends(roles("super_admin","hq_admin","regional_manager","store_manager"))):
    r=s.scalar(select(ShiftSwap).where(ShiftSwap.id==rid,ShiftSwap.organization_id==u.organization_id,ShiftSwap.status=="pending"))
    if not r:raise HTTPException(404,"找不到待審核換班")
    a=s.get(ShiftAssignment,r.from_assignment_id);sh=s.get(Shift,a.shift_id);new=s.get(Employee,r.to_employee_id)
    if x.approved:
        warnings=_compliance_for_employee(s,u.organization_id,new,sh)
        if warnings:raise HTTPException(409,"換班檢核未通過："+"；".join(warnings))
        old=s.get(Employee,a.employee_id);old.weekly_hours=max(0,old.weekly_hours-_duration(sh.start_time,sh.end_time));new.weekly_hours+=_duration(sh.start_time,sh.end_time);a.employee_id=new.id
    r.status="approved" if x.approved else "rejected";s.commit();audit(s,u,r.status,"shift_swap",rid,"主管審核");return {"status":r.status}

@app.post("/api/sales")
def add_sales(x:SalesIn,s:Session=Depends(db),u:User=Depends(roles("super_admin","hq_admin","regional_manager","store_manager"))):
    st=s.scalar(select(Store).where(Store.id==x.store_id,Store.organization_id==u.organization_id))
    if not st:raise HTTPException(404,"門市不存在")
    m=SalesMetric(organization_id=u.organization_id,**x.model_dump());s.add(m);s.commit();audit(s,u,"create","sales_metric",m.id,str(x.metric_date));return {"id":m.id}

@app.get("/api/forecast")
def forecast(store_id:Optional[int]=None,s:Session=Depends(db),u:User=Depends(current_user)):
    q=select(SalesMetric).where(SalesMetric.organization_id==u.organization_id)
    if store_id:q=q.where(SalesMetric.store_id==store_id)
    rows=s.scalars(q.order_by(SalesMetric.metric_date.desc()).limit(90)).all()
    if rows:
        avg_sales=sum(x.sales_amount for x in rows)/len(rows);avg_customers=sum(x.customer_count for x in rows)/len(rows)
        suggested=max(1,round(avg_customers/35))
        return {"source":"使用已輸入的歷史營業資料估算","records":len(rows),"avg_daily_sales":round(avg_sales,2),"avg_daily_customers":round(avg_customers,1),"suggested_staff":suggested,"confidence":"初步估算，資料量與季節性會影響準確度"}
    return {"source":"尚無歷史營業資料","records":0,"avg_daily_sales":0,"avg_daily_customers":0,"suggested_staff":None,"confidence":"請先匯入門市營業額與來客數，系統才可建立需求預測；目前不虛構預測數字"}

@app.get("/api/analytics")
def analytics(s:Session=Depends(db),u:User=Depends(current_user)):
    org=u.organization_id;stores=s.scalars(select(Store).where(Store.organization_id==org,Store.active==True)).all();rows=[]
    for st in stores:
        emps=s.scalars(select(Employee).where(Employee.organization_id==org,Employee.home_store_id==st.id)).all()
        shifts=s.scalars(select(Shift).where(Shift.organization_id==org,Shift.store_id==st.id)).all()
        hours=sum(_duration(x.start_time,x.end_time)*x.assigned_count for x in shifts)
        rows.append({"store":st.name,"employees":len(emps),"required":sum(x.required_count for x in shifts),"assigned":sum(x.assigned_count for x in shifts),"shortage":sum(max(0,x.required_count-x.assigned_count) for x in shifts),"estimated_hours":round(hours,1)})
    return {"stores":rows,"total_shortage":sum(x["shortage"] for x in rows)}

@app.get("/api/labor-check")
def labor_check(s:Session=Depends(db),u:User=Depends(current_user)):
    alerts=[]
    for a in s.scalars(select(ShiftAssignment).where(ShiftAssignment.organization_id==u.organization_id,ShiftAssignment.status=="assigned")).all():
        sh=s.get(Shift,a.shift_id);e=s.get(Employee,a.employee_id)
        if not sh or not e:continue
        for w in _compliance_for_employee(s,u.organization_id,e,sh):alerts.append({"employee":e.name,"date":str(sh.shift_date),"shift":sh.shift_name,"warning":w})
    return {"alerts":alerts,"count":len(alerts),"disclaimer":"這是排班風險提示，不構成法律意見或正式勞基法合規認證。實際規則須依行業、工時制度、例假休息日、變形工時、加班核准及最新法令由人資/法務確認。"}

@app.get("/api/costs")
def costs(s:Session=Depends(db),u:User=Depends(current_user)):
    setting=s.scalar(select(WageSetting).where(WageSetting.organization_id==u.organization_id))
    rate=setting.hourly_cost if setting else 190
    if not setting:s.add(WageSetting(organization_id=u.organization_id,hourly_cost=rate));s.commit()
    data=[]
    for st in s.scalars(select(Store).where(Store.organization_id==u.organization_id,Store.active==True)).all():
        shs=s.scalars(select(Shift).where(Shift.organization_id==u.organization_id,Shift.store_id==st.id)).all()
        hours=sum(_duration(x.start_time,x.end_time)*x.assigned_count for x in shs)
        sales=s.scalar(select(func.sum(SalesMetric.sales_amount)).where(SalesMetric.organization_id==u.organization_id,SalesMetric.store_id==st.id)) or 0
        cost=hours*rate;data.append({"store":st.name,"hours":round(hours,1),"estimated_cost":round(cost,2),"sales":round(sales,2),"labor_ratio":round(cost/sales*100,1) if sales else None})
    return {"hourly_cost_assumption":rate,"stores":data,"note":"成本為示範估算，尚未納入勞健保、勞退、加班費、津貼及薪資系統資料。"}

@app.put("/api/settings/wage")
def set_wage(x:WageIn,s:Session=Depends(db),u:User=Depends(roles("super_admin","hq_admin"))):
    r=s.scalar(select(WageSetting).where(WageSetting.organization_id==u.organization_id))
    if not r:r=WageSetting(organization_id=u.organization_id,hourly_cost=x.hourly_cost);s.add(r)
    else:r.hourly_cost=x.hourly_cost
    s.commit();audit(s,u,"update","wage_setting",r.id,str(x.hourly_cost));return {"hourly_cost":r.hourly_cost}

@app.get("/api/notifications")
def notifications(s:Session=Depends(db),u:User=Depends(current_user)):
    return [{"id":n.id,"title":n.title,"message":n.message,"channel":n.channel,"status":n.status,"created_at":n.created_at.isoformat()} for n in s.scalars(select(InAppNotification).where(InAppNotification.organization_id==u.organization_id).order_by(InAppNotification.id.desc()).limit(100)).all()]

@app.get("/api/rewards")
def rewards(s:Session=Depends(db),u:User=Depends(current_user)):
    out=[]
    for e in s.scalars(select(Employee).where(Employee.organization_id==u.organization_id)).all():
        pts=s.scalar(select(func.sum(RewardLedger.points)).where(RewardLedger.organization_id==u.organization_id,RewardLedger.employee_id==e.id)) or 0
        out.append({"employee":e.name,"employee_no":e.employee_no,"points":pts})
    return out

@app.post("/api/assistant")
def assistant(x:AssistantIn,s:Session=Depends(db),u:User=Depends(current_user)):
    q=x.question.lower();org=u.organization_id
    shortages=s.scalar(select(func.count(Shift.id)).where(Shift.organization_id==org,Shift.required_count>Shift.assigned_count)) or 0
    stores=s.scalar(select(func.count(Store.id)).where(Store.organization_id==org,Store.active==True)) or 0
    employees=s.scalar(select(func.count(Employee.id)).where(Employee.organization_id==org)) or 0
    if any(k in q for k in ["缺工","缺人","人力不足"]):answer=f"目前有 {shortages} 個班別存在人力缺口。建議先到「班表與缺工」執行跨店媒合，再由主管核准。"
    elif any(k in q for k in ["門市","幾間店"]):answer=f"目前管理 {stores} 間啟用門市，共 {employees} 位員工。"
    elif any(k in q for k in ["法規","勞基法","工時"]):answer="請先查看「法規檢查」的排班風險提示。此為輔助檢查，正式合規仍需人資/法務依適用制度確認。"
    elif any(k in q for k in ["成本","人事費"]):answer="請查看「人力成本」頁面；目前成本依管理者設定的示範時薪與班表時數估算。"
    else:answer=f"我已取得目前營運摘要：{stores} 間門市、{employees} 位員工、{shortages} 個缺工班別。你可以詢問缺工、門市、人力成本或法規風險。"
    return {"answer":answer,"engine":"AOM AI 規則型營運助理展示版","requires_external_llm":True}

@app.get("/api/integrations")
def integrations(u:User=Depends(current_user)):
    return [{"name":"n8n 自動化","status":"可由環境變數設定 Webhook","configured":bool(N8N_WEBHOOK_URL)},{"name":"LINE Messaging API","status":"待填入官方憑證與員工同意","configured":False},{"name":"HR/薪資/打卡/POS","status":"待客戶 API 或檔案格式確認","configured":False},{"name":"地圖距離/通勤時間","status":"待設定地圖服務金鑰","configured":False},{"name":"SSO/MFA","status":"正式企業版待整合","configured":False}]

